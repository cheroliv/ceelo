package game.ceelo.backend.security

const val ADMIN: String = "ROLE_ADMIN"
const val USER: String = "ROLE_USER"
const val ANONYMOUS: String = "ROLE_ANONYMOUS"
